$(function(){
	var w_w=$(window).width();
	var m_l=(1920-w_w)/2;
	$('.head .nav li:last-child').css('margin-right',0);
	$('.i_m li:last-child').css('margin-right',0);
	$('.f_nav li:last-child').css('margin-right',0);
	$('.i_me li:nth-child(5n)').css('margin-right',0);
	$('.pro ul li:nth-child(3n)').css('margin-right',0);
	
	
})
